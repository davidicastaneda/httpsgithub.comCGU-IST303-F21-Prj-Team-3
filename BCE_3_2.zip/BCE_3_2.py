#Task 1 answer
Beatles_list=['George,guitar','John,guitar','Paul,bass','Ringo,drums']
#Task 2 answer
beatles_dict={'George':'Guitar','John':'Guitar','Paul':'Bass','Ringo':'drums'}
#task 3 answer
stones_list=['Mick,piano','Keith,guitar','Charlie,drums','Ronnie,guitar']
#task 4 answer
stones_dict={'Mick':'piano','Keith':'guitar','Charlie':'drums','Ronnie':'guitar'}
#task 5 answer
bands_dict={'Beatles':'beatles_dict','Stones':'stones_dict'}
#task 6 answer
bands_dict.get('Ringo')
