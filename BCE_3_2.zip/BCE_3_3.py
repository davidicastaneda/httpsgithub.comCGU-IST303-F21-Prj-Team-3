answer=input("1.-List the best musical group ever 2. - List the best sports team ever 3.-Quit")
if answer == "1":
    print ("The Beatles are the best ever");
elif answer =="2":
    print ("The Cubs are the best ever");
elif answer =="3":
    print ("OK! Hope you learned something.");
else: 
    print ("That's not one of the choices. Try Again.");